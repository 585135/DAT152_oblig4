package com.api.rest.controller;
import com.api.rest.models.Item;
import com.api.rest.repositories.ItemDAOMemorySingleton;
import com.google.gson.Gson;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;



@RestController

public class ApiControllers {

	@GetMapping(value = "/")
	public String getPage() {

		return "welcome to Items API";
	}

	@GetMapping(value = "/items")
	public String getItems(Model model) {
			
		final List<Item> items = ItemDAOMemorySingleton.getInstance().findAllItems();
		
		String json = new Gson().toJson(items);
		
		
		model.addAttribute("items", items);
		
		return "Your items: " + json;
	
	}

	@GetMapping(value = "/items/{id}")
	protected String viewItem(@PathVariable String id, Model model) {
		
		if(ItemDAOMemorySingleton.getInstance().findItem(id) != null){
		
		        final Item item = ItemDAOMemorySingleton.getInstance().findItem(id);
		        model.addAttribute("item", item);
		        
		        String json = new Gson().toJson(item);
		
		        return "viewitem" + json;
		    }
		else {
			
			
			 throw new ResponseStatusException(
			           HttpStatus.NOT_FOUND, " Not Found");
		
		}
		
	}

	@PostMapping(value = "/items")
	protected String createItem(@RequestParam String id, @RequestParam String name, 
            @RequestParam Double price, @RequestParam String description, 
            Model model) {

			final Item newItem = new Item(id, name, price, description);
			ItemDAOMemorySingleton.getInstance().createItem(newItem); 

			return "success";
	}

	@PutMapping(value = "/items")
	public String putItem(@RequestParam String id, @RequestParam String name, 
            @RequestParam Double price, @RequestParam String description, 
            Model model) {
		
		final Item updatedItem = new Item(id, name, price, description);
		ItemDAOMemorySingleton.getInstance().updateItem(id, updatedItem);
		
		
		return "Item updated";
	}

	@DeleteMapping(value = "/items/{id}")
	public String DeleteItem(@PathVariable String id, Model model) {
		ItemDAOMemorySingleton.getInstance().deleteItem(id);
		
		
		return "success";
	}

}
